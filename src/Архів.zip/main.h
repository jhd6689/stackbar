/* date = May 19th 2020 7:13 pm */

#ifndef MAIN_H
#define MAIN_H

#include "application.h"

extern App *app;

extern bool restart;

#endif// MAIN_H
