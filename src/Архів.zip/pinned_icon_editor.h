//
// Created by jmanc3 on 5/12/21.
//

#ifndef WINBAR_PINNED_ICON_EDITOR_H
#define WINBAR_PINNED_ICON_EDITOR_H

#include "container.h"

void start_pinned_icon_editor(Container *icon_container);


#endif //WINBAR_PINNED_ICON_EDITOR_H
