//
// Created by jmanc3 on 5/21/21.
//

#include "globals.h"

globals *global = nullptr;
