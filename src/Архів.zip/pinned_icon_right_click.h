/* date = June 8th 2020 2:38 am */

#ifndef PINNED_ICON_RIGHT_CLICK_H
#define PINNED_ICON_RIGHT_CLICK_H

#include "application.h"

void start_pinned_icon_right_click(Container *container);

#endif// PINNED_ICON_RIGHT_CLICK_H
